export class AccountOwner {
    constructor(public name:string="init name",public address:string="",public tz:number=-1,public hasPicture:boolean=false)
    {}
}
