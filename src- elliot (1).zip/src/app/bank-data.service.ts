import { Injectable } from '@angular/core';
import { UserCredentials } from './user-credentials';
import * as CryptoJS from 'crypto-js';
import { BankTransaction } from './bank-transaction';
import { AccountOwner } from './account-owner';
import { BankAccountDetails } from './bank-account-details';
const USER_CREDENTIALS_KY: string = "USER_CREDENTIALS";
const OWNER_KY: string = "OWNER";
const ACCOUNT_KY: string = "ACCOUNT";
const SALT: string = "mko)9Ijn8UhErtb";
const TRANSACTION_KY: string = "TRANSACTIONS"; 
@Injectable({
  providedIn: 'root'
})
export class BankDataService {
  private menuVisible:Boolean=false;
  public updateMenu:boolean=false;
  currentUser?: UserCredentials;
  theUserCredential: UserCredentials | null = null;
  private allTransactions: BankTransaction[] = [];
  private mone: number = 1;
  currentAccountOwner?: AccountOwner;
  theAccountOwner: AccountOwner | null = null;
  currentBankAccount?:BankAccountDetails;
  theBankAccount: BankAccountDetails | null = null;
  tranNum?:number;
  constructor() {
    this.loadFillUser();
    this.loadFillAccountOwner();
    this.loadFillBankAccount();
    this.loadTransactions();
    this.mone = this.allTransactions.length + 1;
  }

  getMenuVisibility():Boolean
  {
      return this.menuVisible;
  }
  setMenuVisibility(nwStat:Boolean):void
  {
      this.menuVisible=nwStat;
  }

  public eraseTransaction(trannumber:number){
    if(this.allTransactions[trannumber].trnTyp != 0){
      let count = 0;
      for(let i = trannumber + 1; i < this.allTransactions.length; i++){
        var newsidouri = `#${i}`;
        this.allTransactions[i].sidouri = newsidouri;
        if(this.allTransactions[trannumber].trnTyp == 1){

          if(this.allTransactions[i].balanceAfterTrn - this.allTransactions[trannumber].amount < -2000){
            alert("מחיקת פעולה זו לא אפשרית כיוון שהיא תגרום לחריגה.");
            var oldsidouri = `#${i+1}`;
            this.allTransactions[i].sidouri=oldsidouri;
            i--;
            while(count>0){
              this.allTransactions[i].balanceAfterTrn += this.allTransactions[trannumber].amount;
              var oldsidouri = `#${i+1}`;
              this.allTransactions[i].sidouri=oldsidouri;
              i--;
              count--;
            }
            return;
          }
          else{
            this.allTransactions[i].balanceAfterTrn -= this.allTransactions[trannumber].amount;
          }
        }
        else if(this.allTransactions[trannumber].trnTyp == 2){
          this.allTransactions[i].balanceAfterTrn += this.allTransactions[trannumber].amount;
        }
        count++;
      }

      this.allTransactions.splice(trannumber,1);
      this.mone--;
      this.updateMenu = true;
      this.saveTransactions();
    }
    else{
      alert("לא ניתן למחוק פעולת פתיחת חשבון.");
      return;
    }
  }

  private loadFillAccountOwner():void{
    const parmanentStr: string | null = localStorage.getItem(OWNER_KY);
    if (!parmanentStr) {
      this.loadInitAccountOwnerData();
    }
    else{
      try {
        this.theAccountOwner = JSON.parse(parmanentStr);
      }
      catch (prblm) {
        alert("בעיה במקור הנתונים, טוען נתוני Mock");
        this.loadInitAccountOwnerData();
      }
    }
  }

  private loadFillBankAccount():void{
    const parmanentStr: string | null = localStorage.getItem(ACCOUNT_KY);
    if (!parmanentStr) {
      this.loadInitBankAccountData();
    }
    else{
      try {
        this.theBankAccount = JSON.parse(parmanentStr);
      }
      catch (prblm) {
        alert("בעיה במקור הנתונים, טוען נתוני Mock");
        this.loadInitBankAccountData();
      }
    }
  }

  private loadInitBankAccountData():void{
    const t: string = JSON.stringify(new BankAccountDetails("Givatayim", 762, 113344));
    this.theBankAccount = JSON.parse(t);
    this.updateBankAccountStorage();
  }

  private updateBankAccountStorage():void{
    const savedStr = JSON.stringify(this.theBankAccount);
    try {
      localStorage.setItem(ACCOUNT_KY, savedStr); 
    }
    catch (prblm) {
      alert("שמירת הנתונים נכשלה");
    }
  }

  private loadFillUser(): void {
    const parmanentStr: string | null = localStorage.getItem(USER_CREDENTIALS_KY);// the preferd syntax
    //same as const parmanentStr=localStorage[this.parmanentKy];
    if (!parmanentStr) {//אין אחסון של נתונים בלוקל סטורג
      this.loadInitUserCredentialsData();
    }
    else
      try {//ניסיון לטעון הנתונים מהלוקל סטורג
        this.theUserCredential = JSON.parse(parmanentStr);
      }
      catch (prblm) {//הנתונים בלוקל סטורג לא תקינים
        alert("בעיה במקור הנתונים, טוען נתוני Mock");
        this.loadInitUserCredentialsData();
      }
  }

  addTransaction(transaction:BankTransaction):void{
    this.allTransactions.push(transaction);
    this.mone++;
    this.saveTransactions();
    this.updateMenu = true;
  }
  getNumTransactions():number{
    return this.allTransactions.length;
  }
  getTransaction(transactionumber:number):BankTransaction{
    return this.allTransactions[transactionumber];
  }
  getMone():number{
    return this.mone;
  }

  isCredentialOk(inVlus: UserCredentials): boolean {
    return (inVlus.eml == this.theUserCredential?.eml && this.encrptPwd(inVlus.pwd) == this.theUserCredential.pwd);
  }

  encrptPwd(pwd: string): string {
    return CryptoJS.SHA3(pwd + SALT, { outputLength: 512 }).toString();
  }
  
  loadInitUserCredentialsData(): void {
    const t: string = JSON.stringify(new UserCredentials("siteAdmin@bigbank.com", this.encrptPwd("1234")));
    this.theUserCredential = JSON.parse(t);
    this.updateUSerStorage();
  }

  loadInitAccountOwnerData():void{
    const t: string = JSON.stringify(new AccountOwner("plonit almonit", "ta", 129387465, false));
    this.theAccountOwner = JSON.parse(t);
    this.updateOwnerStorage();
  }

  updateOwnerStorage(): void {
    const savedStr = JSON.stringify(this.theAccountOwner);
    try {
      localStorage.setItem(OWNER_KY, savedStr); 
    }
    catch (prblm) {
      alert("שמירת הנתונים נכשלה");
    }
  }

  updateUSerStorage(): void {
    const savedStr = JSON.stringify(this.theUserCredential);
    try {
      localStorage.setItem(USER_CREDENTIALS_KY, savedStr); // the preferd syntax
      // same as localStorage[this.parmanentKy]=savedStr
    }
    catch (prblm) {
      alert("שמירת הנתונים נכשלה");
    }
  }

  setCurrentUsr(usr: UserCredentials): void {
    this.currentUser = usr;
  }

  setCurrentOwner(ownr:AccountOwner):void{
    this.currentAccountOwner = ownr;
    localStorage.removeItem("OWNER");
    const text = JSON.stringify(this.currentAccountOwner) 
    localStorage.setItem("OWNER", text);
    this.updateMenu = true;
    }

  setCurrentAccount(account:BankAccountDetails):void{
    this.currentBankAccount = account;
    localStorage.removeItem("ACCOUNT");
    const text = JSON.stringify(this.currentBankAccount) 
    localStorage.setItem("ACCOUNT", text);
  }

  loadTransactions(){
    const parmanentStr: string | null = localStorage.getItem(TRANSACTION_KY);
    if (!parmanentStr) {
    }
    else{
      try {
        this.allTransactions = JSON.parse(parmanentStr);
      }
      catch (prblm) {
        console.log(prblm);
        alert("בעיה במקור הנתונים, טוען נתוני Mock");
        //this.loadInitBankAccountData();
      }
    }
  }

  saveTransactions(){
    var data ="";
    localStorage.removeItem(TRANSACTION_KY);
      data = data + JSON.stringify(this.allTransactions);
    localStorage.setItem(TRANSACTION_KY, data);
  }

  userSignedIn(): boolean {
    return this.currentUser != undefined;
  }

  userDisconnect(): void {
    this.currentUser = undefined;
  }

  isPwdOk(typdPwd: string): boolean {
    return (this.theUserCredential?.pwd + "" == this.encrptPwd(typdPwd));
  }

  changePwd(nwPwd: string): void {
    if (this.theUserCredential)
      this.theUserCredential.pwd = this.encrptPwd(nwPwd);
  }

}
