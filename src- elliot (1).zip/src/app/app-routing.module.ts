import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccountLoginComponent } from './account-login/account-login.component';
import { AccountOwnerComponent } from './account-owner/account-owner.component';
import { BankAccountComponent } from './bank-account/bank-account.component';
import { ChangeAccountDetailsComponent } from './change-account-details/change-account-details.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { MagishAvodaComponent } from './magish-avoda/magish-avoda.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { TransactionDetailsComponent } from './transaction-details/transaction-details.component';
import { TransactionsTableComponent } from './transactions-table/transactions-table.component';

const routes: Routes = [
  { path: 'MagishAvoda', component:  MagishAvodaComponent},
  { path: 'AccountOwner', component:  AccountOwnerComponent},
  { path: 'ChangeAccountDetails', component: ChangeAccountDetailsComponent},
  { path: 'TransactionsTable', component: TransactionsTableComponent},
  { path: 'AccountLogin', component: AccountLoginComponent },
  { path: 'BankAccount', component: BankAccountComponent },
  { path: 'ChangePassword', component: ChangePasswordComponent },
  { path: 'TransactionDetails', component: TransactionDetailsComponent },
  { path: '', redirectTo: '/MagishAvoda', pathMatch: 'full' },
  { path: '**', component: PageNotFoundComponent }
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
