import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccountOwner } from '../account-owner';
import { BankDataService } from '../bank-data.service';
import { BankTransaction } from '../bank-transaction';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  public update :boolean = this.data_svc.updateMenu;
  public name: string = "";
  public picture:boolean = false;
  public tz :number = -1;
  public owner:AccountOwner = this.data_svc.theAccountOwner || new AccountOwner();
  public lasttransaction?: BankTransaction;
  constructor(private router_srv: Router, private data_svc: BankDataService) {
    this.setAccountOwnerName();
    this.setLastTransaction();
   }

  ngOnInit(): void {

  }
  updateMenu(){
    if(this.data_svc.updateMenu == true){
      if(this.data_svc.currentAccountOwner?.name == undefined ){

      }
      else{
        this.name = this.data_svc.currentAccountOwner?.name;
        this.picture = this.data_svc.currentAccountOwner?.hasPicture;
        this.tz =this.data_svc.currentAccountOwner?.tz;
      }
      this.setLastTransaction();
      this.data_svc.updateMenu = false;
      this.update = false;
    }
  }

  logOut(): void {
    this.data_svc.userDisconnect();
    this.router_srv.navigateByUrl("/AccountLogin");
  }

  setLastTransaction(){
    if(this.data_svc.getNumTransactions() > 0){
      this.lasttransaction= this.data_svc.getTransaction(this.data_svc.getNumTransactions() - 1);
    }
  }

  showMenu():Boolean{
    return this.data_svc.getMenuVisibility();
  }

  setAccountOwnerName(){
    if(this.data_svc.theAccountOwner != null){
      this.name = this.data_svc.theAccountOwner.name || "plonit almonit";
      this.picture = this.data_svc.theAccountOwner.hasPicture;
      this.tz = this.data_svc.theAccountOwner.tz;
      this.data_svc.setCurrentOwner(this.owner);
    }
    else this.name = "plonit almonit";
  }

  getAccountOwnerName():string{
    return this.name;
  }

}
