import { Component, inject, Injectable, Input } from '@angular/core';
import { Router } from '@angular/router';
import { BankDataService } from '../bank-data.service';
import { BankTransaction, TransactionType } from '../bank-transaction';

@Component({
  selector: 'app-transaction-details',
  templateUrl: './transaction-details.component.html',
  styleUrls: ['./transaction-details.component.css']
})

@Injectable({
  providedIn: 'root'
})

export class TransactionDetailsComponent {
  @Input()trannum: number = 0;
  @Input()transaction: BankTransaction = new BankTransaction(this.data_svc.getTransaction(this.trannum).amount, this.data_svc.getTransaction(this.trannum).trnDate, this.data_svc.getTransaction(this.trannum).balanceAfterTrn, this.data_svc.getTransaction(this.trannum).asmachta, this.data_svc.getTransaction(this.trannum).trnTyp, this.data_svc.getTransaction(this.trannum).sidouri, this.data_svc.getTransaction(this.trannum).description);
  public type : string = "";
  public edit : boolean = false;

  constructor(private router_srv:Router,private data_svc: BankDataService){
      this.getTranNum();
      this.getType();
      this.transaction = new BankTransaction(this.data_svc.getTransaction(this.trannum).amount, this.data_svc.getTransaction(this.trannum).trnDate, this.data_svc.getTransaction(this.trannum).balanceAfterTrn, this.data_svc.getTransaction(this.trannum).asmachta, this.data_svc.getTransaction(this.trannum).trnTyp, this.data_svc.getTransaction(this.trannum).sidouri, this.data_svc.getTransaction(this.trannum).description);
  }

  ngOnInit(): void {
    this.data_svc.setMenuVisibility(false);
    if (!this.data_svc.userSignedIn()){
      this.router_srv.navigateByUrl("/AccountLogin");
      }
  }

  getTranNum(){
    if(this.data_svc.tranNum != undefined){
      this.trannum = this.data_svc.tranNum;
    }
  }

  getType():void{
    let rslt="";
    switch(this.data_svc.getTransaction(this.trannum).trnTyp * 1)
    {
      case TransactionType.openAcount: rslt = "Account oppening"; break;
      case TransactionType.deposit: rslt = "Deposit"; break;
      case TransactionType.withdraw: rslt = "Withdrawal"; break;
    }
    this.type = rslt;
  }

  eraseTransaction():void{
    var userPreference;
    if(confirm(`האם למחוק את פעולה ${this.transaction.sidouri}?`)==true){
      this.data_svc.eraseTransaction(this.trannum);
      this.toList();
    }
    else{

    }
  }

  toList():void{
    this.router_srv.navigateByUrl("TransactionsTable");
  }
}
