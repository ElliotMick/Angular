import { Component } from '@angular/core';

@Component({
  selector: 'app-magish-avoda',
  templateUrl: './magish-avoda.component.html',
  styleUrls: ['./magish-avoda.component.css']
})
export class MagishAvodaComponent {
  year: string = "תשפ''ב";
  magishdetails: string = "337745269, אליוט פליירן";
  course: string = "תכנות ווב - צד לקוח (833561801)";
  profnames:string = "ד''ר מילר ומר עמיחי פיינגבוים";

  constructor(){};
}
