import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { AccountOwner } from '../account-owner';
import { BankAccountDetails } from '../bank-account-details';
import { BankDataService } from '../bank-data.service';
import { TransactionType, BankTransaction } from '../bank-transaction';

@Component({
  selector: 'app-bank-account',
  templateUrl: './bank-account.component.html',
  styleUrls: ['./bank-account.component.css']
})

export class BankAccountComponent implements OnInit {
  currentAmount: number = 0;
  currentBalance: number = 0;
  transaction?: BankTransaction = undefined;
  accountDetails: BankAccountDetails;
  currentTransactionType: TransactionType = -1;
  currentTransactionAsmachta: string = "";
  currentTransactionDateS: string = "";
  currentTransactionDescription: string = "";
  currentTransactionMone: string = "#";
  currentOwner: AccountOwner = new AccountOwner("plonit almonit", "ta", 129387465);
  transactionTypeNames: string[] = [];
  lastActionFail: boolean = false;
  editAccountOwner: boolean = false;
  editAccountDetails: boolean = false;
  showTransactions: boolean = false;

  constructor(private router_srv: Router, private data_svc: BankDataService) {
    //this.transaction = new BankTransaction(1000, undefined, "opening", TransactionType.openAcount);
    this.accountDetails = new BankAccountDetails("Rimonim Givataim", 762, 113344);
    if(this.data_svc.getNumTransactions() != 0){
      this.currentBalance = this.data_svc.getTransaction(this.data_svc.getNumTransactions() - 1).balanceAfterTrn;
    }


    for (let optn in TransactionType)
      if (isNaN(Number(optn)))
        this.transactionTypeNames.push(optn);

  }

  doTransaction(): void {
    this.lastActionFail = false;
    if (this.currentAmount == null || this.currentAmount < 0) {
      showErrorFocus("סכום חייב להיות מספר לא שלילי", "amount");
      return;
    }
    if (this.currentTransactionAsmachta == null || this.currentTransactionAsmachta.trim() == "") {
      this.currentTransactionAsmachta = this.currentTransactionMone + this.data_svc.getMone().toString();
      /*showErrorFocus("אסמכתא לפחות 4 תוים", "asmachta");
      return;*/
    }
    if (this.currentTransactionDateS == "") {
      showErrorFocus("תאריך חובה", "taarich");
      return;
    }
    let achshav: Date = new Date();
    let typedDt: Date = new Date(this.currentTransactionDateS);
    if (typedDt > achshav) {
      showErrorFocus("תאריך מאוחר מהיום אסור", "taarich");
      return;
    }

    if(this.getNumTransactions() != 0){
      let previousTrnDt: Date = new Date(this.getTransaction(this.getNumTransactions() - 1).trnDate);
      if(typedDt < previousTrnDt){
        showErrorFocus("תאריך התנועה לא יכול להיות לפני תאריך התנועה הקודמת", "taarich");
        return;
      }
    }

    switch (this.currentTransactionType * 1) {
      case TransactionType.openAcount: this.currentBalance = this.currentAmount;
        break;
      case TransactionType.deposit: this.currentBalance += this.currentAmount;
        break;
      case TransactionType.withdraw: if ((this.currentBalance - this.currentAmount) < this.accountDetails.limit) {
        this.lastActionFail = true;
        return;
      }
        this.currentBalance -= this.currentAmount;
        break;
      default: alert('לא בחרת סוג פעולה');
        return;

    }
    if( this.getNumTransactions() == 0){
      switch(this.currentTransactionType * 1){
        case TransactionType.openAcount:
        this.currentTransactionMone += this.data_svc.getMone().toString();
        this.transaction = new BankTransaction(this.currentAmount, new Date(this.currentTransactionDateS), this.currentBalance, this.currentTransactionAsmachta.trim(), this.currentTransactionType, this.currentTransactionMone, this.currentTransactionDescription);
        this.data_svc.addTransaction(this.transaction);
        this.currentTransactionAsmachta= "";
        this.currentTransactionMone="#";
        break;

        case TransactionType.deposit:
        this.currentBalance = this.currentAmount; this.currentTransactionType = TransactionType.openAcount;
        this.currentTransactionDescription = "הפיכת פעולת ההפקדה לפתיחת חשבון";
        this.currentTransactionMone += this.data_svc.getMone().toString();
        this.transaction = new BankTransaction(this.currentAmount, new Date(this.currentTransactionDateS), this.currentBalance, this.currentTransactionAsmachta.trim(), this.currentTransactionType, this.currentTransactionMone, this.currentTransactionDescription);
        this.data_svc.addTransaction(this.transaction);
        this.currentTransactionDescription = "";
        this.currentTransactionAsmachta= "";
        this.currentTransactionMone="#";
        break;

        case TransactionType.withdraw: 
        alert('לא ניתן למשוך כסף כל עוד לא נפתח חשבון');
        return;
      }
    }
    else{
      if(this.currentTransactionType==0){
        showErrorFocus("לא ניתן לעשות פעולת פתיחת חשבון לאחר שהוא כבר נפתח", "sugpeula");
        return;
      }
      
      this.currentTransactionMone += this.data_svc.getMone().toString();
      this.transaction = new BankTransaction(this.currentAmount, new Date(this.currentTransactionDateS), this.currentBalance, this.currentTransactionAsmachta.trim(), this.currentTransactionType, this.currentTransactionMone, this.currentTransactionDescription);
      this.data_svc.addTransaction(this.transaction);
      this.currentTransactionAsmachta= "";
      this.currentTransactionMone="#";
    }
  }

  setOwner():void{
    this.data_svc.setCurrentOwner(this.currentOwner);
  }

  setAccountDetails():void{
    this.data_svc.setCurrentAccount(this.accountDetails)
  }

  getNumTransactions():number{
    return this.data_svc.getNumTransactions();
  }

  getTransaction(transactionumber:number):BankTransaction{
    return this.data_svc.getTransaction(transactionumber);
  }

  getMone():number{
    return this.data_svc.getMone();
  }

  toString(): string {
    let ezer = `${this.transaction} into ${this.accountDetails}`;
    return ezer;
  }

  ngOnInit(): void {
    this.data_svc.setMenuVisibility(true);
    if (!this.data_svc.userSignedIn()){
      this.router_srv.navigateByUrl("/AccountLogin");
      }
  }

  logOut(): void {
    this.data_svc.userDisconnect();
    this.router_srv.navigateByUrl("/AccountLogin");
  }

}
function showErrorFocus(msg: string, id: string): void {
  alert(msg);
  document.getElementById(id)?.focus();
}
