import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccountOwner } from 'src/app/account-owner';
import { BankDataService } from '../bank-data.service';


@Component({
  selector: 'app-account-owner',
  templateUrl: './account-owner.component.html',
  styleUrls: ['./account-owner.component.css']
})
export class AccountOwnerComponent implements OnInit {
  @Input() owner:AccountOwner=new AccountOwner();
  @Input() edit?:boolean;

  constructor(private router_srv: Router, private data_svc: BankDataService) {
    if(this.data_svc.theAccountOwner!= null){
      this.owner = this.data_svc.theAccountOwner;
    }
   }
   setOwner(){
    this.data_svc.setCurrentOwner(this.owner);
   }

   cancelChange(){
    const previousowner : string | null = localStorage.getItem("OWNER");
    if (!previousowner) {
    }
    else{
      this.owner = JSON.parse(previousowner);
    }
   }

  ngOnInit(): void {
    this.data_svc.setMenuVisibility(true);
    if (!this.data_svc.userSignedIn()){
      this.router_srv.navigateByUrl("/AccountLogin");
      }
  }

}
