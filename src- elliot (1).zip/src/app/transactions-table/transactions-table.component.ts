import { Component, Injectable, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BankDataService } from '../bank-data.service';
import { TransactionType, BankTransaction } from '../bank-transaction';

@Component({
  selector: 'app-transactions-table',
  templateUrl: './transactions-table.component.html',
  styleUrls: ['./transactions-table.component.css']
})

@Injectable({
  providedIn: 'root'
})

export class TransactionsTableComponent implements OnInit{
  @Input() table: BankTransaction[] = [];
  @Input() edit?:boolean;
  transactionTypeNames: string[] = [];


  constructor(private router_srv:Router, private data_svc: BankDataService) {
    for (let optn in TransactionType)
      if (isNaN(Number(optn)))
        this.transactionTypeNames.push(optn);
  }

  fillArray():void
  {
    if(this.table.length <= this.data_svc.getNumTransactions()){
      for(let i = 0; this.data_svc.getNumTransactions() > i; i++)
      {
        this.table.push(this.data_svc.getTransaction(i));
      }
    }
    else{
      return;
    }
  }

  emptyArray():void{

      this.table.splice(0);

  }

  sendTranNum(trannum:number):void{
    this.data_svc.tranNum = trannum;
  }

 ngOnInit(): void {
    this.data_svc.setMenuVisibility(true);
    if (!this.data_svc.userSignedIn()){
      this.router_srv.navigateByUrl("/AccountLogin");
      }
  }

}
