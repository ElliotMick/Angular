import { Component, Input, OnInit} from '@angular/core';
import { Router } from '@angular/router';
import { BankAccountDetails } from '../bank-account-details';
import { BankDataService } from '../bank-data.service';

@Component({
  selector: 'app-change-account-details',
  templateUrl: './change-account-details.component.html',
  styleUrls: ['./change-account-details.component.css']
})
export class ChangeAccountDetailsComponent implements OnInit{
  @Input() account:BankAccountDetails = new BankAccountDetails();
  @Input() edit?:boolean;
  details?:string =`${this.account.bankName} Branch: (${this.account.branchNumber}) ${this.account.branchName} Account#: ${this.account.accountNumber}`;

  constructor(private router_srv: Router, private data_svc:BankDataService) { 
    if(this.data_svc.theBankAccount!= null){
      this.account = this.data_svc.theBankAccount;
      this.details = `${this.account.bankName} Branch: (${this.account.branchNumber}) ${this.account.branchName} Account#: ${this.account.accountNumber}`;
    }
  }
  
  setAccountDetails(){
    this.data_svc.setCurrentAccount(this.account);
    this.details = `${this.account.bankName} Branch: (${this.account.branchNumber}) ${this.account.branchName} Account#: ${this.account.accountNumber}`;
  }

  cancelChange(){
    const previoudetails : string | null = localStorage.getItem("ACCOUNT");
    if (!previoudetails) {
    }
    else{
      this.account = JSON.parse(previoudetails);
    }
   }

 ngOnInit(): void {
  this.data_svc.setMenuVisibility(true);
  if (!this.data_svc.userSignedIn()){
    this.router_srv.navigateByUrl("/AccountLogin");
    }
 }

}
